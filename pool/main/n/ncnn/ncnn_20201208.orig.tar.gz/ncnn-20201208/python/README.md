Here is python binding for ncnn library, developed by community developer

Thanks to caishanli ! 感谢！

https://github.com/caishanli/pyncnn
