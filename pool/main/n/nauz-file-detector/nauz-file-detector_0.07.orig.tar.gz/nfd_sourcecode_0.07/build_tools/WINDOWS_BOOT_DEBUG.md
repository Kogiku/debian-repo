Boot Parameters to Debug the Boot Process in Windows
=====

To enable boot debugging, use the **BCDEdit /bootdebug** command

More info: https://docs.microsoft.com/en-us/windows-hardware/drivers/devtest/boot-parameters-to-enable-debugging
