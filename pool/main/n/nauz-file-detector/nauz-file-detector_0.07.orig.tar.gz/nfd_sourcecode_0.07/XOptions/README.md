Options for projects
