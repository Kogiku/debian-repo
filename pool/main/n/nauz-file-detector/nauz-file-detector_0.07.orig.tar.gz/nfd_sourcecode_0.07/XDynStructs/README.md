# XDynStructs

Structs for xntsv
