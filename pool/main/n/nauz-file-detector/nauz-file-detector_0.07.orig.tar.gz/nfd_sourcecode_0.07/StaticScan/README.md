#

Static scan for Nauz File Detector.
