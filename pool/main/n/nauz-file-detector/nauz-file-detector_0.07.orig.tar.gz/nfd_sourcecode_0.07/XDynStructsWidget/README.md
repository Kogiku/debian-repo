# XDynStructsWidget

Widget for structs
