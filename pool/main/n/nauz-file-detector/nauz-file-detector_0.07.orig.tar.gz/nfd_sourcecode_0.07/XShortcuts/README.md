Shortcuts for projects
