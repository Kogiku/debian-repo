Shortcuts for projects:

* Detect It Easy: https://github.com/horsicq/Detect-It-Easy
* XAPKDetector: https://github.com/horsicq/XAPKDetector
* XELFViewer: https://github.com/horsicq/XELFViewer
* XPEViewer: https://github.com/horsicq/XPEViewer
* XMACHOViewer: https://github.com/horsicq/XMACHOViewer
* PDBRipper: https://github.com/horsicq/PDBRipper
* XNTSV: https://github.com/horsicq/xntsv
