Enable kernel debugging in Windows
=====

Before setting **BCDEdit** options you might need to disable or suspend **BitLocker** and **Secure Boot** on the computer.

bcdedit /debug on 

More info: https://docs.microsoft.com/en-us/windows-hardware/drivers/devtest/bcdedit--debug
