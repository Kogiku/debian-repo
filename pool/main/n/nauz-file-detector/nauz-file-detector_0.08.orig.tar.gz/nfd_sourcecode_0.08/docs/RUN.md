
* **nfd** GUI version
* **nfdc** console version

How to run portable version on Linux
=======

- download an appImage file (https://github.com/horsicq/Nauz-File-Detector/releases/download/0.08/NauzFileDetector-0.08-x86_64.AppImage)
- make the file executable (chmod +x NauzFileDetector-0.08-x86_64.AppImage)
- run it (./NauzFileDetector-0.08-x86_64.AppImage)
