# SpecAbstract

Signatures for Nauz File Detector.
