How to runn app in OSX that’s not signed by a developer
=======
- Right-click the app(Ctrl + Click).
- Select Open.
- OSX pops up a prompt warning the app is from an unidentified developer. Click Open to continue.

More info: https://www.macworld.com/article/229130/how-to-install-an-app-in-macos-sierra-thats-not-signed-by-a-developer.html