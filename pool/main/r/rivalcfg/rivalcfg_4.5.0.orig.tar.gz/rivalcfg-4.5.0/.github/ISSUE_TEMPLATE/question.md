---
name: I have a question
about: Choose this if you have a question about Rivalcfg
title: ''
labels: question
assignees: ''

---

<!-- -------------------------------------------------------------------------

Please read the FAQ first:

* https://flozz.github.io/rivalcfg/faq.html

You may also read the "contributing" documentation:

* https://flozz.github.io/rivalcfg/contributing.html#questions

-------------------------------------------------------------------------- -->


<!-- Ask your question here -->
