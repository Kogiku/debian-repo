multidpi_range
==============

.. automodule:: rivalcfg.handlers.multidpi_range
   :members:
