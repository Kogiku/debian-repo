none
====

.. automodule:: rivalcfg.handlers.none
   :members:
