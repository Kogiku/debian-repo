choice
======

.. automodule:: rivalcfg.handlers.choice
   :members:
