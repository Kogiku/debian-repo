rgbgradientv2
=============

.. NOTE::

   This is a variation of the :ref:`rgbgradient` handler that supports devices
   like the Rival 700, 710.

.. automodule:: rivalcfg.handlers.rgbgradientv2
   :members:
