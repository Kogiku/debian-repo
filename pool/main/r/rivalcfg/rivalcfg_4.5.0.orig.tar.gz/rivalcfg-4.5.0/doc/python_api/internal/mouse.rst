mouse
=====

Factory Function
----------------

.. autofunction:: rivalcfg.mouse.get_mouse


Mouse Class
-----------

.. autoclass:: rivalcfg.mouse.Mouse
   :members:
   :private-members:
