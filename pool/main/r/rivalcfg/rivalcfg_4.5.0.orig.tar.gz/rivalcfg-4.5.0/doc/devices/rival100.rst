SteelSeries Rival 100 and Rival 105
===================================


Supported Models
----------------

.. rivalcfg_device_family:: rival100


Command-Line Usage
------------------

.. rivalcfg_device_cli:: rival100


Colors
------

This mouse supports colors. Various formats are supported.

.. include:: ./_colors.rst


Python API
----------

TODO
