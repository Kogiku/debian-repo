SteelSeries Rival 600
=====================


Supported Models
----------------

.. rivalcfg_device_family:: rival600


Command-Line Usage
------------------

.. rivalcfg_device_cli:: rival600


Colors
------

This mouse supports colors. Various formats are supported.

.. include:: ./_colors.rst


RGB Gradients
-------------

.. include:: ./_rgbgradient.rst


Python API
----------

TODO
