SteelSeries Rival 300 and original Rival
========================================


Supported Models
----------------

.. rivalcfg_device_family:: rival300


Command-Line Usage
------------------

.. rivalcfg_device_cli:: rival300


Colors
------

This mouse supports colors. Various formats are supported.

.. include:: ./_colors.rst


Buttons
-------

.. figure:: ./images/rival_300_buttons.svg
   :alt: Rival 300 and Original buttons schema

.. include:: ./_buttons.rst


Python API
----------

TODO
