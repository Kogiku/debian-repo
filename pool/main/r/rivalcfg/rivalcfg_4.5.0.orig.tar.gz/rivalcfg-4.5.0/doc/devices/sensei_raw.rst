SteelSeries Sensei [RAW]
========================


Supported Models
----------------

.. rivalcfg_device_family:: sensei_raw


Command-Line Usage
------------------

.. rivalcfg_device_cli:: sensei_raw


Buttons
-------

.. figure:: ./images/sensei_raw_buttons.svg
   :alt: Sensei [RAW] buttons schema

.. include:: ./_buttons.rst


Python API
----------

TODO
