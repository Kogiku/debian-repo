.. _devices:

Supported Devices
=================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   ./aerox3.rst
   ./aerox3_wireless.rst
   ./kanav2.rst
   ./kinzuv2.rst
   ./prime.rst
   ./rival3.rst
   ./rival3_wireless.rst
   ./rival95.rst
   ./rival100.rst
   ./rival110.rst
   ./rival300.rst
   ./rival300s.rst
   ./rival310.rst
   ./rival500.rst
   ./rival600.rst
   ./rival650.rst
   ./rival700.rst
   ./sensei310.rst
   ./sensei_raw.rst
   ./sensei_ten.rst
