SteelSeries Sensei TEN
======================


Supported Models
----------------

.. rivalcfg_device_family:: sensei_ten


Command-Line Usage
------------------

.. rivalcfg_device_cli:: sensei_ten


Colors
------

This mouse supports colors. Various formats are supported.

.. include:: ./_colors.rst


RGB Gradients
-------------

.. include:: ./_rgbgradient.rst


Buttons
-------

.. figure:: ./images/sensei_ten_buttons.svg
   :alt: Sensei TEN buttons schema

.. include:: ./_buttons.rst


Python API
----------

TODO
