High Level Python API
=====================

Rivalcfg high level API is what you want to use to interact with any supported
mouse from your own scripts.

.. automodule:: rivalcfg
   :members:
