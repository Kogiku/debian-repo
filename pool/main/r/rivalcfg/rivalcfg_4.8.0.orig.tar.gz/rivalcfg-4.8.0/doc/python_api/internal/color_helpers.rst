color_helpers
=============

.. automodule:: rivalcfg.color_helpers
   :members:
