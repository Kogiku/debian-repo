.. _rgbgradient:

rgbgradient
===========

.. automodule:: rivalcfg.handlers.rgbgradient
   :members:
