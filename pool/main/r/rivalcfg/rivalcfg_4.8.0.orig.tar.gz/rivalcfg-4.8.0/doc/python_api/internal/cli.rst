cli
===

.. automodule:: rivalcfg.cli
   :members:
