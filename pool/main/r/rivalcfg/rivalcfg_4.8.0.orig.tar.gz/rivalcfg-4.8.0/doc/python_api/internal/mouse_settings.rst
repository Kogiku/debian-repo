mouse_settings
==============

Factory Function
----------------

.. autofunction:: rivalcfg.mouse_settings.get_mouse_settings


MouseSettings Class
-------------------

.. autoclass:: rivalcfg.mouse_settings.MouseSettings
   :members:
   :private-members:


Helper functions
----------------

.. autofunction:: rivalcfg.mouse_settings.get_xdg_config_home

.. autofunction:: rivalcfg.mouse_settings.get_settings_path
