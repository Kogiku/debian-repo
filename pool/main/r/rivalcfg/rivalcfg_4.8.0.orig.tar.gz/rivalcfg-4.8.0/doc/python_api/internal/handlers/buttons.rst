buttons
=======

.. automodule:: rivalcfg.handlers.buttons.buttons
   :members:
