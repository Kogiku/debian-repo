rgbcolor
========

.. automodule:: rivalcfg.handlers.rgbcolor
   :members:
