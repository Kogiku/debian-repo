helpers
=======

.. automodule:: rivalcfg.helpers
   :members:
