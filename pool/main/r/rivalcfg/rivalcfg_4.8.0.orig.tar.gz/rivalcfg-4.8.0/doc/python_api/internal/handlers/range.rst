range
=====

.. automodule:: rivalcfg.handlers.range
   :members:
