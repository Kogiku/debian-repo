devices
=======

.. automodule:: rivalcfg.devices
   :members:
