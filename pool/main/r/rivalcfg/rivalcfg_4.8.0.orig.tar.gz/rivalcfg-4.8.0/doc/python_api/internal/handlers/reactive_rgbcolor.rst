reactive_rgbcolor
=================

.. automodule:: rivalcfg.handlers.reactive_rgbcolor
   :members:
