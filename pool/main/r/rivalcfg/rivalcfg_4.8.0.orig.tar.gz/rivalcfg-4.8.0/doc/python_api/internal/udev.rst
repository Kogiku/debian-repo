udev
======

.. automodule:: rivalcfg.udev
   :members:
