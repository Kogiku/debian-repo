SteelSeries Rival 95 and Rival 100 PC Bang
==========================================

The Rival 95 and the Rival 100 PC Bang Edition is a low end version of the Rival 100 that does not have LEDs.


Supported Models
----------------

.. rivalcfg_device_family:: rival95


Command-Line Usage
------------------

.. rivalcfg_device_cli:: rival95


Python API
----------

TODO
