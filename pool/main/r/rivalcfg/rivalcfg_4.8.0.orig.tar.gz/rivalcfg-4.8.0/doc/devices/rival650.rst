SteelSeries Rival 650
=====================


Supported Models
----------------

.. rivalcfg_device_family:: rival650


Missing Features
----------------

The following feature are currently not supported by Rivalcfg:

* Color / illumination
* Wheel mapping
* Lifting distance configuration


Command-Line Usage
------------------

.. rivalcfg_device_cli:: rival650


Buttons
-------

.. figure:: ./images/rival_650_buttons.svg
   :alt: Rival 650 buttons schema

.. include:: ./_buttons.rst


Python API
----------

TODO
