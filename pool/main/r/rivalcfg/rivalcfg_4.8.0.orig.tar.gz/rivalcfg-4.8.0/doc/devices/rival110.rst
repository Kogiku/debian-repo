SteelSeries Rival 110 and Rival 106
===================================


Supported Models
----------------

.. rivalcfg_device_family:: rival110


Command-Line Usage
------------------

.. rivalcfg_device_cli:: rival110


Colors
------

This mouse supports colors. Various formats are supported.

.. include:: ./_colors.rst


Python API
----------

TODO
