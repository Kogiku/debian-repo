SteelSeries Kana v2
===================


Supported Models
----------------

.. rivalcfg_device_family:: kanav2


Command-Line Usage
------------------

.. rivalcfg_device_cli:: kanav2


Python API
----------

TODO
