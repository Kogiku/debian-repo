SteelSeries Rival 700 and Rival 710
===================================


Supported Models
----------------

.. rivalcfg_device_family:: rival700


Missing Features
----------------

The following feature are currently not supported by Rivalcfg:

* OLED screen image


Command-Line Usage
------------------

.. rivalcfg_device_cli:: rival700


Colors
------

This mouse supports colors. Various formats are supported.

.. include:: ./_colors.rst


RGB Gradients
-------------

.. include:: ./_rgbgradient.rst


Python API
----------

TODO
