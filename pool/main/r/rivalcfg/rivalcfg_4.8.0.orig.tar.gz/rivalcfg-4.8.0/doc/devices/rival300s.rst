SteelSeries Rival 300S
======================

This device looks like a Rival 300 but works like a Rival 110.


Supported Models
----------------

.. rivalcfg_device_family:: rival300s


Command-Line Usage
------------------

.. rivalcfg_device_cli:: rival300s


Colors
------

This mouse supports colors. Various formats are supported.

.. include:: ./_colors.rst


Python API
----------

TODO
