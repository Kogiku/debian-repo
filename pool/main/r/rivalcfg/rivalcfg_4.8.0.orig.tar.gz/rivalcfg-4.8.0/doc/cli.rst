Command-Line Usage
==================

The basic usage is:

.. rivalcfg_device_cli:: None

More options are available depending on the plugged mouse. See :doc:`devices/index` documentation for device-specific options.
