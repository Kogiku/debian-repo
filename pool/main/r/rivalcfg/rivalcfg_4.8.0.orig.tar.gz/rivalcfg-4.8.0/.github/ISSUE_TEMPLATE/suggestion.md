---
name: I want to suggest a new feature
about: Choose this if you have some ideas or suggestions to improve Rivalcfg
title: ''
labels: enhancement
assignees: ''

---

<!-- Describe your idea here -->
