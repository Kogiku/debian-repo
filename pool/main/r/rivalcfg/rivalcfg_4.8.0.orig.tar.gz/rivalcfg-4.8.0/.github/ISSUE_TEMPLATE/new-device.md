---
name: New mouse
about: Choose this if your SteelSeries mouse is not supported yet by Rivalcfg
title: ''
labels: New Hardware
assignees: ''

---

<!-- -------------------------------------------------------------------------

Please read this first:

* https://flozz.github.io/rivalcfg/contributing.html#unsupported-devices

-------------------------------------------------------------------------- -->

Device identification:

```
<!-- Result of the `lsusb -d 1038:` command -->
```

Product URL:

<!-- Please add here a link to the device page on the SteelSeries website or online shop. -->

SSE3 Screenshots:

<!-- If you have a Windows machine, please provide screenshots of the SteelSeries Engine / GG Engine when configuring the mouse. This can help to determine available features. -->
