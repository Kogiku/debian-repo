aoTuV
====

"aoTuV" is software library for encoding and decoding of OggVorbis that modified encoding part of Xiph.Org's libvorbis. 

## License
A license is taken as "BSD-style license" as well as original libvorbis. 
