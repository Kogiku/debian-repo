#ifndef __ULTRA64__HOST__CARTINFO_H__
#define __ULTRA64__HOST__CARTINFO_H__

#include <ultra64/rom.h>

void ultra64_header_info(n64header_t *carthead);

#endif
