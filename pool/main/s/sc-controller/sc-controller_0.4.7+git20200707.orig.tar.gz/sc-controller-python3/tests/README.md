## TESTS

Tests are using [pytest framework](https://docs.pytest.org/en/latest/).

To run all of them, navigate to directory above and do
`$ PYTHONPATH=. py.test2 tests`
