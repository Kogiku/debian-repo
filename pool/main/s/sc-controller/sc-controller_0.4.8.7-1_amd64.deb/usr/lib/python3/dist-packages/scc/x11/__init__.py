#!/usr/bin/env python2
"""
SC-Controller - X11

Daemon-related stuff that really needs X server to work.
"""

# there is also absolutely nothing usefull in this file...