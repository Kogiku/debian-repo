from scc.parser import ActionParser

parser = ActionParser()
