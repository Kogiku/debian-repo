//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� sdlpal.rc ʹ��
//
#define APP_MANIFEST                    1
#define IDI_SDLPAL                      101
#define IDD_LAUNCHER                    101
#define IDS_CONFIRM                     102
#define IDC_DEFAULT                     1000
#define IDC_BRGAME                      1001
#define IDC_GAMEPATH                    1002
#define IDC_ASPECTRATIO                 1003
#define IDC_FULLSCREEN                  1004
#define IDC_TOUCHOVERLAY                1005
#define IDC_USEMSGFILE                  1006
#define IDC_BRMSG                       1007
#define IDC_MSGFILE                     1008
#define IDC_CD                          1009
#define IDC_BGM                         1010
#define IDC_OPL_CORE                    1011
#define IDC_STEREO                      1012
#define IDC_SURROUNDOPL                 1013
#define IDC_SAMPLERATE                  1014
#define IDC_OPLSR                       1015
#define IDC_AUDIOBUFFER                 1016
#define IDC_QUALITY                     1017
#define IDC_SOUNDVOLUME                 1018
#define IDC_MUSICVOLUME                 1019
#define IDC_LOGLEVEL                    1020
#define IDC_USEFONTFILE                 1021
#define IDC_BRFONT                      1022
#define IDC_FONTFILE                    1023
#define IDC_USELOGFILE                  1024
#define IDC_BRLOG                       1025
#define IDC_LOGFILE                     1026
#define IDC_ENABLEAVI                   1027
#define IDC_OPL_CHIP                    1028
#define IDC_GLSL                        1029
#define IDC_HDR                         1030
#define IDC_TEXTUREWIDTH                1031
#define IDC_TEXTUREHEIGHT               1032
#define IDC_BRSHADER                    1033
#define IDC_SHADERFILE                  1034
#define IDC_WINDOWWIDTH                 1035
#define IDC_WINDOWHEIGHT                1036
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
