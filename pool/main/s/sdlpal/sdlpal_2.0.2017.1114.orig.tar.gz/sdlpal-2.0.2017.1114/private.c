#ifdef CYGWIN
	SDLPAL_ICON ICON DISCARDABLE "sdlpal.ico"
#endif
