Wii port uses SDL-wii, which has only 1.2 version.
Build environment: DevKitPPC
Debug requirement: wii_dev_debug