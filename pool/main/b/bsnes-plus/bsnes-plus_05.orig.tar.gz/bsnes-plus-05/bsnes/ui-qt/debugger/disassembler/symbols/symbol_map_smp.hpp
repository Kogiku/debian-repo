const char *DEFAULT_SYMBOL_MAP_SMP =
  "; default registers used for SMP\n" \
  "\n" \
  "[labels]\n" \
  "00:00F0 SMP.UNKNOWN\n" \
  "00:00F1 SMP.CONTROL\n" \
  "00:00F2 SMP.DSP_ADDR\n" \
  "00:00F3 SMP.DSP_DATA\n" \
  "00:00F4 SMP.PORT0\n" \
  "00:00F5 SMP.PORT1\n" \
  "00:00F6 SMP.PORT2\n" \
  "00:00F7 SMP.PORT3\n" \
  "00:00FA SMP.TIMER0\n" \
  "00:00FB SMP.TIMER1\n" \
  "00:00FC SMP.TIMER2\n" \
  "00:00FD SMP.COUNTER0\n" \
  "00:00FE SMP.COUNTER1\n" \
  "00:00FF SMP.COUNTER2\n" \
;
