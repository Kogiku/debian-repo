void supressScreenSaver() {
}

