#include <snes.hpp>

#define BSX_CPP
namespace SNES {
  #include "bsx_base.cpp"
  #include "bsx_cart.cpp"
  #include "bsx_flash.cpp"
  #include "serialization.cpp"
}
