#define ALT_CPU_HPP

class CPU : public Processor, public CPUcore, public PPUcounter, public MMIO {
public:
  enum : bool { Threaded = true };
  array<Processor*> coprocessors;
  alwaysinline void step(unsigned clocks);
  void synchronize_smp();
  void synchronize_ppu();
  void synchronize_coprocessor();

  uint8 pio();
  bool joylatch();
  bool interrupt_pending();
  debugvirtual uint8 mmio_read(unsigned addr);
  debugvirtual void mmio_write(unsigned addr, uint8 data);

  void op_io();
  debugvirtual uint8 op_read(unsigned addr);
  debugvirtual void op_write(unsigned addr, uint8 data);

  void enter();
  void power();
  void reset();

  void serialize(serializer&);
  CPU();
  ~CPU();

private:
  //cpu
  static void Enter();
  debugvirtual void op_step();
  debugvirtual void op_irq(uint16 vector);

  //timing
  struct QueueEvent {
    enum : unsigned {
      DramRefresh,
      HdmaRun,
      ControllerLatch,
    };
  };
  nall::priority_queue<unsigned> queue;
  void queue_event(unsigned id);
  void last_cycle();
  void add_clocks(unsigned clocks);
  void scanline();
  void run_auto_joypad_poll();

  //memory
  unsigned speed(unsigned addr) const;

  //dma
  bool dma_transfer_valid(uint8 bbus, unsigned abus);
  bool dma_addr_valid(unsigned abus);
  debugvirtual uint8 dma_read(unsigned abus);
  void dma_write(bool valid, unsigned addr, uint8 data);
  void dma_transfer(bool direction, uint8 bbus, unsigned abus);
  uint8 dma_bbus(unsigned i, unsigned index);
  unsigned dma_addr(unsigned i);
  unsigned hdma_addr(unsigned i);
  unsigned hdma_iaddr(unsigned i);
  void dma_run();
  bool hdma_active_after(unsigned i);
  void hdma_update(unsigned i);
  void hdma_run();
  void hdma_init();
  void dma_reset();

  struct Channel {
    bool dma_enabled;
    bool hdma_enabled;

    bool direction;
    bool indirect;
    bool unused;
    bool reverse_transfer;
    bool fixed_transfer;
    uint8 transfer_mode;

    uint8 dest_addr;
    uint16 source_addr;
    uint8 source_bank;

    union {
      uint16 transfer_size;
      uint16 indirect_addr;
    };

    uint8 indirect_bank;
    uint16 hdma_addr;
    uint8 line_counter;
    uint8 unknown;

    bool hdma_completed;
    bool hdma_do_transfer;
  } channel[8];

  struct Status {
    bool nmi_valid;
    bool nmi_line;
    bool nmi_transition;
    bool nmi_pending;

    bool irq_valid;
    bool irq_line;
    bool irq_transition;
    bool irq_pending;

    bool irq_lock;
    bool hdma_pending;

    unsigned wram_addr;

    bool joypad_strobe_latch;

    bool nmi_enabled;
    bool virq_enabled;
    bool hirq_enabled;
    bool auto_joypad_poll;

    uint8 pio;

    uint8 wrmpya;
    uint8 wrmpyb;
    uint16 wrdiva;
    uint8 wrdivb;

    uint16 hirq_pos;
    uint16 virq_pos;

    unsigned rom_speed;

    uint16 rddiv;
    uint16 rdmpy;

    uint16 joy1;
    uint16 joy2;
    uint16 joy3;
    uint16 joy4;
  } status;

  friend class CPUDebugger;
};

#if defined(DEBUGGER)
  // now using the same CPU debugger as the other CPU implementation 
  // since they were mostly identical
  #include "../../cpu/debugger/debugger.hpp"
  extern CPUDebugger cpu;
  
  #include "../../cpu/debugger/analyst.hpp"
  extern CPUAnalyst cpuAnalyst;
#else
  extern CPU cpu;
#endif
