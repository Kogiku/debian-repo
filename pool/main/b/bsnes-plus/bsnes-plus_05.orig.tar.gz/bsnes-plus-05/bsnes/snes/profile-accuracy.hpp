namespace Info {
  static const char Profile[] = "Accuracy";
}

#include <cpu/cpu.hpp>
#include <smp/smp.hpp>
#include <dsp/dsp.hpp>
#include <ppu/ppu.hpp>
