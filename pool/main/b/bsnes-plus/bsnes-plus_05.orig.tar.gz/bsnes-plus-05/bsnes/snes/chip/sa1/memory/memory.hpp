alwaysinline void op_io();
debugvirtual alwaysinline uint8 op_read(unsigned addr);
debugvirtual alwaysinline void op_write(unsigned addr, uint8 data);

uint8_t vbr_read(unsigned addr);
