namespace Info {
  static const char Profile[] = "Compatibility";
}

#include <cpu/cpu.hpp>
#include <smp/smp.hpp>
#include <alt/dsp/dsp.hpp>
#include <alt/ppu-compatibility/ppu.hpp>
