namespace Info {
  static const char Profile[] = "Performance";
}

#include <alt/cpu/cpu.hpp>
#include <smp/smp.hpp>
#include <alt/dsp/dsp.hpp>
#include <alt/ppu-performance/ppu.hpp>
