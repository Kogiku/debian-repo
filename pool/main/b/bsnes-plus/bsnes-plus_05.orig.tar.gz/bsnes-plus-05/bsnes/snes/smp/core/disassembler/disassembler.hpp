void disassemble_opcode(char *output, uint16 addr);
inline uint16 relb(int8 offset, int op_len, uint16 pc);
