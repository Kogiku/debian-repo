// copyright (c) 2020 hors<horsicq@gmail.com>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
#include "dialogentropyprocess.h"
#include "ui_dialogentropyprocess.h"

DialogEntropyProcess::DialogEntropyProcess(QWidget *parent, QIODevice *pDevice,EntropyProcess::DATA *pData) :
    QDialog(parent),
    ui(new Ui::DialogEntropyProcess)
{
    ui->setupUi(this);

    pEntropyProcess=new EntropyProcess;
    pThread=new QThread;

    pEntropyProcess->moveToThread(pThread);

    connect(pThread, SIGNAL(started()), pEntropyProcess, SLOT(process()));
    connect(pEntropyProcess, SIGNAL(completed(qint64)), this, SLOT(onCompleted(qint64)));
    connect(pEntropyProcess, SIGNAL(errorMessage(QString)), this, SLOT(errorMessage(QString)));
    connect(pEntropyProcess, SIGNAL(progressValueChanged1(qint32)), this, SLOT(progressValueChanged1(qint32)));
    connect(pEntropyProcess, SIGNAL(progressValueMinimum1(qint32)), this, SLOT(progressValueMinimum1(qint32)));
    connect(pEntropyProcess, SIGNAL(progressValueMaximum1(qint32)), this, SLOT(progressValueMaximum1(qint32)));
    connect(pEntropyProcess, SIGNAL(progressValueChanged2(qint32)), this, SLOT(progressValueChanged2(qint32)));
    connect(pEntropyProcess, SIGNAL(progressValueMinimum2(qint32)), this, SLOT(progressValueMinimum2(qint32)));
    connect(pEntropyProcess, SIGNAL(progressValueMaximum2(qint32)), this, SLOT(progressValueMaximum2(qint32)));

    pEntropyProcess->setData(pDevice,pData);
    pThread->start();
}

DialogEntropyProcess::~DialogEntropyProcess()
{
    pEntropyProcess->stop();

    pThread->quit();
    pThread->wait();

    delete ui;

    delete pThread;
    delete pEntropyProcess;
}

void DialogEntropyProcess::on_pushButtonCancel_clicked()
{
    pEntropyProcess->stop();
}

void DialogEntropyProcess::errorMessage(QString sText)
{
    QMessageBox::critical(this,tr("Error"),sText);
}

void DialogEntropyProcess::onCompleted(qint64 nElapsed)
{
    Q_UNUSED(nElapsed)

    accept();
}

void DialogEntropyProcess::progressValueChanged1(qint32 nValue)
{
    ui->progressBar1->setValue(nValue);
}

void DialogEntropyProcess::progressValueMaximum1(qint32 nValue)
{
    ui->progressBar1->setMaximum(nValue);
}

void DialogEntropyProcess::progressValueMinimum1(qint32 nValue)
{
    ui->progressBar1->setMinimum(nValue);
}

void DialogEntropyProcess::progressValueChanged2(qint32 nValue)
{
    ui->progressBar2->setValue(nValue);
}

void DialogEntropyProcess::progressValueMaximum2(qint32 nValue)
{
    ui->progressBar2->setMaximum(nValue);
}

void DialogEntropyProcess::progressValueMinimum2(qint32 nValue)
{
    ui->progressBar2->setMinimum(nValue);
}
