# XEntropyWidget
