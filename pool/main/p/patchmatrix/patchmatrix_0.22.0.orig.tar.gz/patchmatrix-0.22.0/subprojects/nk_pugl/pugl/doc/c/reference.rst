#############
API Reference
#############

This section contains the generated documentation for all symbols in the public
API.

.. toctree::

   api/status
   api/world
   api/view
   api/events

   api/cairo
   api/gl
   api/stub
   api/vulkan
