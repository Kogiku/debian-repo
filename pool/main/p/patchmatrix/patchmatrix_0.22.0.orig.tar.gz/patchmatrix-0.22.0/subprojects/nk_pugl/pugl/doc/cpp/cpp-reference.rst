#################
C++ API Reference
#################

This section contains the generated documentation for all symbols in the public
C++ API.

.. toctree::

   api/statusxx
   api/worldxx
   api/viewxx
   api/eventsxx

   api/cairoxx
   api/glxx
   api/stubxx
   api/vulkanxx
