Files leftover from the time of forking.

Most of these are very outdated or completely unused.

These will be stored here for now.

Note: Some of the files contain comments in Japanese or are completely Japanese.

Translation would be needed if those files are even still relevant. (like the Python script)