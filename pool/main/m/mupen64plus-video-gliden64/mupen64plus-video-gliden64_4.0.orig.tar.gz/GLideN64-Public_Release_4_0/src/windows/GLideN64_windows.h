#ifndef GLIDEN64_WINDOWS_H
#define GLIDEN64_WINDOWS_H

#include <windows.h>

extern HWND			hWnd;
extern HWND			hStatusBar;
extern HWND			hToolBar;
extern HINSTANCE	hInstance;

#endif // GLIDEN64_WINDOWS_H
