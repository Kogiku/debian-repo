#ifndef GLIDEN64_H
#define GLIDEN64_H

extern char	pluginName[];
extern wchar_t	pluginNameW[];
extern void (*CheckInterrupts)( void );

#endif // GLIDEN64_H
