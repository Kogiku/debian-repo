#include "../MemoryStatus.h"

bool isMemoryWritable(void * ptr, size_t byteCount)
{
	return true;
}
