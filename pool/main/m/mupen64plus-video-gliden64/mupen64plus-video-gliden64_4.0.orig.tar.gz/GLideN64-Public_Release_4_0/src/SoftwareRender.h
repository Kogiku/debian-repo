#ifndef SOFTWARE_RENDER_H
#define SOFTWARE_RENDER_H

#include "gSP.h"

f32 renderTriangles(const SPVertex * _pVertices, const u16 * _pElements, u32 _numElements);

#endif // SOFTWARE_RENDER_H
