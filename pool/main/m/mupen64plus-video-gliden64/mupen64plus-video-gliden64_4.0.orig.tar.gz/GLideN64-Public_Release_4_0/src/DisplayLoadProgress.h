#ifndef DISPLAYLOADPROGRESS_H
#define DISPLAYLOADPROGRESS_H

void displayLoadProgress(const wchar_t *format, ...);

#endif // DISPLAYLOADPROGRESS_H
