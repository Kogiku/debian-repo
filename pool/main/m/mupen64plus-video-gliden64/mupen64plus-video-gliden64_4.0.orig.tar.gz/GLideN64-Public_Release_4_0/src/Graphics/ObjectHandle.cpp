#include "ObjectHandle.h"

namespace graphics {

ObjectHandle ObjectHandle::null;
ObjectHandle ObjectHandle::defaultFramebuffer;

}
