#ifndef ZSORTBOSS_H
#define ZSORTBOSS_H

void ZSortBOSS_Init();

#endif // ZSORTBOSS_H
