#ifndef L3DEX_H
#define L3DEX_H
#include "Types.h"

void L3DEX_Line3D( u32 w0, u32 w1 );
void L3DEX_Init();
#endif

