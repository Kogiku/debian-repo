#ifndef F3DAM_H
#define F3DAM_H

void F3DAM_Init();

#endif // F3DAM_H
