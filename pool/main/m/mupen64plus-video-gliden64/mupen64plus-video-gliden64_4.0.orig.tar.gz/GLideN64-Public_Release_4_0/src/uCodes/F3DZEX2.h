#ifndef F3DZEX2_H
#define F3DZEX2_H

void F3DZEX2_Init();

#endif // F3DEX2M_H
