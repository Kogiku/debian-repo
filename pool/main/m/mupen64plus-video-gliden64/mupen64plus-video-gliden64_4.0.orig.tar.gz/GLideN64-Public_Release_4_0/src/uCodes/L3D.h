#ifndef L3D_H
#define L3D_H
#include "Types.h"

#define L3D_LINE3D				0xB5

void L3D_Line3D( u32 w0, u32 w1 );
void L3D_Init();
#endif

