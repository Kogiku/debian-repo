#ifndef F5ROGUE_H
#define F5ROGUE_H

void F5Rogue_Init();

#endif // F5ROGUE_H
