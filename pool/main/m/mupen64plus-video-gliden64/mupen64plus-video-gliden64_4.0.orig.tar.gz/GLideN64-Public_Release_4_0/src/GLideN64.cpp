char pluginName[] = "GLideN64";
wchar_t pluginNameW[] = L"GLideN64";
void (*CheckInterrupts)( void );
